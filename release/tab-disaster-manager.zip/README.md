# Tab Disaster Manager

一个基于 Manifest V3 的智能标签页管理扩展，面向 Chrome / Edge / Firefox。

## 功能概览

- 重复标签页检测与一键清理（保留最早标签页）
- 基于域名的自动分组、展开/折叠、数量与内存估算
- 实时搜索（普通 / 模糊 / 正则）并高亮匹配内容
- 工作区保存、选择性恢复、导入与导出

## 项目结构

```text
manifest.json
src/
  background.js
  content-script.js
  core/
    tab-manager.js
    url-utils.js
    workspace-store.js
  popup/
    popup.html
    popup.css
    popup.js
tests/
docs/
```

## 开发与测试

```bash
npm install
npm test
```

## 文档

- [安装指南](./docs/install.md)
- [用户操作文档](./docs/user-guide.md)
- [性能测试报告](./docs/performance-report.md)
