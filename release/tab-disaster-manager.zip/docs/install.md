# 安装指南

## Chrome / Edge（开发者模式）

1. 打开扩展管理页：`chrome://extensions` 或 `edge://extensions`
2. 打开“开发者模式”
3. 点击“加载已解压的扩展程序”
4. 选择本项目根目录 `tab_manager`
5. 固定扩展图标后即可使用

## Firefox（临时加载）

1. 打开 `about:debugging#/runtime/this-firefox`
2. 点击“临时载入附加组件”
3. 选择项目中的 `manifest.json`
4. 在工具栏中点击扩展图标使用

## 打包分发建议

- Chrome/Edge：将项目目录压缩为 zip 上传至商店
- Firefox：使用 AMO 打包流程并校验 `browser_specific_settings`
