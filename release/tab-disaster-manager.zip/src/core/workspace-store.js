const STORAGE_KEY = "savedWorkspaces"

export function sanitizeWorkspaceName(name) {
  return (name || "").trim().slice(0, 60)
}

export function createWorkspaceRecord(name, tabs) {
  const safeName = sanitizeWorkspaceName(name) || `工作区-${new Date().toISOString()}`
  return {
    id: crypto.randomUUID(),
    name: safeName,
    createdAt: Date.now(),
    tabs: tabs.map((tab) => ({
      title: tab.title || "",
      url: tab.url || "",
      pinned: Boolean(tab.pinned)
    }))
  }
}

export async function loadWorkspaces(storage) {
  const data = await storage.local.get(STORAGE_KEY)
  return Array.isArray(data[STORAGE_KEY]) ? data[STORAGE_KEY] : []
}

export async function saveWorkspaces(storage, workspaces) {
  await storage.local.set({ [STORAGE_KEY]: workspaces })
  return workspaces
}

export async function addWorkspace(storage, workspace) {
  const existing = await loadWorkspaces(storage)
  const next = [workspace, ...existing]
  await saveWorkspaces(storage, next)
  return next
}

export async function deleteWorkspaceById(storage, id) {
  const existing = await loadWorkspaces(storage)
  const next = existing.filter((item) => item.id !== id)
  await saveWorkspaces(storage, next)
  return next
}

export function serializeWorkspaces(workspaces) {
  return JSON.stringify({ version: 1, workspaces }, null, 2)
}

export function deserializeWorkspaces(raw) {
  const parsed = JSON.parse(raw)
  if (!parsed || !Array.isArray(parsed.workspaces)) {
    throw new Error("无效的工作区文件")
  }
  return parsed.workspaces
}
