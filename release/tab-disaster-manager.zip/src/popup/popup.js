import { searchTabs } from "../core/tab-manager.js"

const ext = globalThis.browser ?? globalThis.chrome

const state = {
  snapshot: {
    tabs: [],
    groupedTabs: [],
    duplicateGroups: [],
    duplicateCount: 0,
    duplicateRules: {}
  },
  workspaces: [],
  searchQuery: "",
  searchMode: "normal",
  expandedGroups: new Set()
}

const $ = (id) => document.getElementById(id)

function setStatus(message) {
  $("statusText").textContent = message
}

function escapeHtml(text) {
  return text
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;")
}

function highlightText(rawText, query, mode) {
  const text = rawText || ""
  if (!query) {
    return escapeHtml(text)
  }

  if (mode === "regex") {
    try {
      const regex = new RegExp(query, "ig")
      return escapeHtml(text).replace(regex, (segment) => `<mark>${segment}</mark>`)
    } catch {
      return escapeHtml(text)
    }
  }

  const lower = text.toLowerCase()
  const q = query.toLowerCase()
  const index = lower.indexOf(q)
  if (index === -1 || mode === "fuzzy") {
    return escapeHtml(text)
  }
  const head = escapeHtml(text.slice(0, index))
  const center = escapeHtml(text.slice(index, index + q.length))
  const tail = escapeHtml(text.slice(index + q.length))
  return `${head}<mark>${center}</mark>${tail}`
}

function sendMessage(payload) {
  return new Promise((resolve, reject) => {
    ext.runtime.sendMessage(payload, (response) => {
      if (ext.runtime.lastError) {
        reject(new Error(ext.runtime.lastError.message))
        return
      }
      if (!response?.ok) {
        reject(new Error(response?.error || "操作失败"))
        return
      }
      resolve(response.data)
    })
  })
}

async function refreshSnapshot() {
  const data = await sendMessage({ type: "GET_TAB_SNAPSHOT" })
  state.snapshot = data
  state.expandedGroups = new Set(data.groupedTabs.slice(0, 3).map((group) => group.domain))
  $("duplicateSummary").textContent = `重复标签：${data.duplicateCount}`
  $("ignoreQuery").checked = Boolean(data.duplicateRules.ignoreQuery)
  $("ignoreHash").checked = Boolean(data.duplicateRules.ignoreHash)
  $("ignoreProtocol").checked = Boolean(data.duplicateRules.ignoreProtocol)
  $("ignoreWww").checked = Boolean(data.duplicateRules.ignoreWww)
  renderGroups()
  renderSearchResults()
}

async function refreshWorkspaces() {
  state.workspaces = await sendMessage({ type: "LIST_WORKSPACES" })
  renderWorkspaces()
}

function renderGroups() {
  const root = $("groupContainer")
  root.innerHTML = ""
  for (const group of state.snapshot.groupedTabs) {
    const expanded = state.expandedGroups.has(group.domain)
    const card = document.createElement("article")
    card.className = "group"
    card.innerHTML = `
      <div class="group-header">
        <strong>${escapeHtml(group.domain)}</strong>
        <button data-domain="${escapeHtml(group.domain)}">${expanded ? "折叠" : "展开"}</button>
      </div>
      <div class="group-meta">标签页 ${group.tabCount} | 估算内存 ${group.estimatedMemoryMb} MB</div>
      <div class="tab-list" style="display:${expanded ? "flex" : "none"};">
        ${group.tabs
          .slice(0, 12)
          .map(
            (tab) => `
            <div class="item">
              <div class="tab-title">${escapeHtml(tab.title || "无标题")}</div>
              <div class="tab-url">${escapeHtml(tab.url || "")}</div>
            </div>`
          )
          .join("")}
      </div>
    `
    root.appendChild(card)
  }

  root.querySelectorAll("button[data-domain]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const domain = btn.getAttribute("data-domain")
      if (!domain) {
        return
      }
      if (state.expandedGroups.has(domain)) {
        state.expandedGroups.delete(domain)
      } else {
        state.expandedGroups.add(domain)
      }
      renderGroups()
    })
  })
}

function renderSearchResults() {
  const root = $("searchResults")
  const results = searchTabs(state.snapshot.tabs, state.searchQuery, state.searchMode).slice(0, 120)
  root.innerHTML = results
    .map(
      (tab) => `
      <article class="item">
        <div class="tab-title">${highlightText(tab.title || "无标题", state.searchQuery, state.searchMode)}</div>
        <div class="tab-url">${highlightText(tab.url || "", state.searchQuery, state.searchMode)}</div>
      </article>
    `
    )
    .join("")
}

function renderWorkspaces() {
  const root = $("workspaceList")
  root.innerHTML = state.workspaces
    .map((workspace) => {
      const createdAt = new Date(workspace.createdAt).toLocaleString()
      return `
      <article class="workspace" data-id="${workspace.id}">
        <div class="group-header">
          <strong>${escapeHtml(workspace.name)}</strong>
          <span class="group-meta">${workspace.tabs.length} 个标签页</span>
        </div>
        <div class="group-meta">${createdAt}</div>
        <div class="tab-list">
          ${workspace.tabs
            .slice(0, 6)
            .map(
              (tab, idx) => `
              <label>
                <input type="checkbox" data-index="${idx}" checked />
                ${escapeHtml(tab.title || tab.url || "无标题")}
              </label>
            `
            )
            .join("")}
        </div>
        <div class="row gap">
          <button data-action="restore" data-id="${workspace.id}">恢复选中</button>
          <button data-action="delete" data-id="${workspace.id}">删除</button>
        </div>
      </article>
    `
    })
    .join("")

  root.querySelectorAll("button[data-action]").forEach((button) => {
    button.addEventListener("click", async () => {
      const action = button.getAttribute("data-action")
      const workspaceId = button.getAttribute("data-id")
      if (!workspaceId) {
        return
      }
      try {
        if (action === "restore") {
          const box = root.querySelector(`article[data-id="${workspaceId}"]`)
          const checked = [...box.querySelectorAll('input[type="checkbox"][data-index]:checked')].map((node) =>
            Number(node.getAttribute("data-index"))
          )
          const result = await sendMessage({
            type: "RESTORE_WORKSPACE",
            workspaceId,
            selectedIndexes: checked
          })
          setStatus(`已恢复 ${result.restoredCount} 个标签页`)
        } else if (action === "delete") {
          await sendMessage({ type: "DELETE_WORKSPACE", workspaceId })
          await refreshWorkspaces()
          setStatus("已删除工作区")
        }
      } catch (error) {
        setStatus(error.message)
      }
    })
  })
}

function bindEvents() {
  $("refreshBtn").addEventListener("click", async () => {
    await refreshSnapshot()
    await refreshWorkspaces()
    setStatus("数据已刷新")
  })

  $("cleanDuplicateBtn").addEventListener("click", async () => {
    const result = await sendMessage({ type: "CLOSE_DUPLICATES" })
    await refreshSnapshot()
    setStatus(`已关闭 ${result.closedCount} 个重复标签页`)
  })

  ;["ignoreQuery", "ignoreHash", "ignoreProtocol", "ignoreWww"].forEach((id) => {
    $(id).addEventListener("change", async () => {
      await sendMessage({
        type: "SET_DUPLICATE_RULES",
        payload: {
          ignoreQuery: $("ignoreQuery").checked,
          ignoreHash: $("ignoreHash").checked,
          ignoreProtocol: $("ignoreProtocol").checked,
          ignoreWww: $("ignoreWww").checked
        }
      })
      await refreshSnapshot()
      setStatus("重复规则已更新")
    })
  })

  $("searchInput").addEventListener("input", () => {
    state.searchQuery = $("searchInput").value.trim()
    renderSearchResults()
  })

  $("searchMode").addEventListener("change", () => {
    state.searchMode = $("searchMode").value
    renderSearchResults()
  })

  $("saveWorkspaceBtn").addEventListener("click", async () => {
    const name = $("workspaceName").value.trim()
    const result = await sendMessage({ type: "SAVE_WORKSPACE", name })
    state.workspaces = result.workspaces
    renderWorkspaces()
    $("workspaceName").value = ""
    setStatus(`工作区已保存：${result.workspace.name}`)
  })

  $("exportWorkspaceBtn").addEventListener("click", async () => {
    const json = await sendMessage({ type: "EXPORT_WORKSPACES" })
    const blob = new Blob([json], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.href = url
    link.download = `workspaces-${Date.now()}.json`
    link.click()
    URL.revokeObjectURL(url)
    setStatus("已导出工作区")
  })

  $("importWorkspaceInput").addEventListener("change", async (event) => {
    const file = event.target.files?.[0]
    if (!file) {
      return
    }
    const raw = await file.text()
    await sendMessage({ type: "IMPORT_WORKSPACES", raw })
    await refreshWorkspaces()
    setStatus("已导入工作区")
  })
}

async function bootstrap() {
  try {
    bindEvents()
    await refreshSnapshot()
    await refreshWorkspaces()
    setStatus("就绪")
  } catch (error) {
    setStatus(error.message)
  }
}

bootstrap()
